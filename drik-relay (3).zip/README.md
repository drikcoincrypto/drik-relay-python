# Telegram Relay on Render
This is a simple Flask app that relays incoming Telegram webhook requests to another server.

## Environment Variables
- BOT_TOKEN: Your Telegram bot token
- RELAY_URL: The URL to relay updates to

## Deployment
Deploy this project to Render and set the environment variables accordingly.
